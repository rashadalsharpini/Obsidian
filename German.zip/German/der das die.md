Der >> r >> Er
Das >> s >> Es
Die >> e >> Sie

Der Tisch ist rot
`=`
Er ist rot
Die Tasche ist klein

Sie ist klein