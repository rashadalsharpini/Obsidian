>[!note] numbers in German
> Null --> zero --> نول 
> Eins --> one  --> اينس 
>  zwei --> two  --> زفاي
>  drei --> 3  --> دغاي 
>  vier --> 4  --> فييا 
>  fünf --> 5  --> فونف
>  sechs --> 6 --> زيكس
>  sieben --> 7 --> زييبن
>  acht  --> 8 --> اخت
>  neun --> 9 --> نوين 
>  zehn --> 10  --> تسين 
>  elf --> 11 --> الف
>  zwölf --> 12 --> تسزفيلف 
>  sechzehn-->16>>تزخشتزسين
>  siebezehn-->17>>زيبتسين
>  zwanzig --> 20 --> 
>  dreißig  --> 30 -->
>  vierzig  --> 40 
>  fünfzig --> 50
>  sechzig --> 60 
>  siebzig --> 70
>  achtzig --> 80
>  neunzig --> 90
>Hundert --> 100


6891
sechs tausend acht hundert eins and neunzig

21122
ein zwanzig tausend ein hundert zwei zwanzig

375241
drei hundert fünf and siebzig tausend zwei hundert ein and vierzig

>[!note]- numbers under one Euro 
> we don't write Euro otherwise we have number less than one yoro 

0.25 --> fünf und zweizig cent
0,99 --> neun und neunzig c
1.50 --> Ein Euro fünfzig 
12,30 --> 
352.83 --> 