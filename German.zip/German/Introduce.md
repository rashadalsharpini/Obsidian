### `ü ß ä ö`

	Ich komme
	Du kommst
	Er/Es/Sie kommt
	Wir/Sie/Sie kommen
	Ihr kommt
---

>[!example]
>Guten tag
>Guten Morgen 
>Guten Abend 
>Gute Nacht
> Gruß Gott
> servus = hello or bye 
> * Tschüs!*  
>  Auf Wiedersehen! --> mean مساء الخير (رسمي) لو بتكلم شخص قدامك
>  Auf Wiederhören --> مساء الخير لكن اذا كان سماع مثل كلام ف الفون
>  
>  

![[Question]]

---
![[numbers in German]]

