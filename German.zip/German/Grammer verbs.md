# Sein = be
# haben = have
الضمير | Sein | Haben 
---|---|---
Ich | bin | habe
Du | bist | hast 
Er/es/sie | ist | hat
Wie/sie/Sie | sind | haben
Ihr | seid | habt

الافعال القوية (غيرة المنتظمة) في المضارع
الافعال القوية بيتغير فيها الجذر و النهاية .. عندنا 3 أشكال لتصريف الأفعال القوية 
و كل شكل بنغير فية الحرف المتحرك و الأشكال هي 

( a >> ä ) 
--
word | الكلمة 
----|----
fahren | يسافر
schlafen | ينام 
lassen | يترك 
tragen  | يرتدي 
waschen | يغسل
laufen | يجرى 
fangen | يلتقط

( e >> i )
--
word | الكلمة
---|---
essen | يأكل
sprechen | يتحدث
nehmen | يأخذ
helfen | يساعد
treffen | يقابل
vergessen | ينسي
geben | يعطي

( e >> ie )
--
word | الكلمة
--|--
lesen | يقرأ
sehen | يري
empfehlen | يرشح
stehlen | يسرق

# التصريف الغير منتظم يظهر مع Du,er,es,sie فقط

مثال علي كل شكل(fahren - lesen - essen)

الضمائر | ( a >> ä ) | ( e >> i ) | ( e >> ie )
---|---|---|---
Ich | fahre | esse | lese 
Du | fahrst | isst | liest
Er/es/sie | fahrt | isst | liest
Wir/sie/Sie | fahren | essen | lesen
Ihr | fahrt | esst | lest

السؤال ب هل
في الجملة الخبرية و السؤال بأدوات الاستفهام لازم الفعل يكون موجود رقم 2 في الجملة
ich spreche englisch.
wer bist du ? 
لو السؤال ب هل الفعل بيكون رقم 1
Sprechen Sie Deutsch ? 
Ja, ich spreche Deutsch.
Nein, ich spreche Arabisch.
Heißt du Ahmed ?
Ja, mein name ist Ahmed.
Nein, mein name ist Omar.

---
![[ArcoLinux-2023-10-28-1698485081_screenshot_1920x1080.jpg]]
