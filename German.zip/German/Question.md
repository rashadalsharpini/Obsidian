>[!faq]
> Wie كيف
> Wer من 
> Woher من أين
> Was ماذا
> Welch- اي



---
## how are you doing??
- Wie geht es dir? كيف احوالك
- Wie geht es Ihnen?
Mir geht es gut

---
## what is your name ??
- Wie heiße Sie? اسم حضرتك؟
- Wie heißt du?
Ich heiße Rashad

___
- Wer bist du?من تكون أنت ؟
- Wie sind sie?
Ich bin Rashad

---
- Wie ist dein name?
- Wie ist Ihr name?
	- Mein name ist Rashad

---
## where are you from??
- Woher kommst du? من أين أنت؟
- Woher kommen Sie? 
	- Ich komme aus Agypton

---
- Wo wohnst au?
- Wo Wohnen Sie?
	- Ich wohne in Cairo

---
## how old are you??
- wie alt bist du --> كم عمرك 
- Wie alt sind Sie --> كم عمر حضرتك 
	- Ich bin ...... 
	Jahre alt ياغا الت= years old 

----------------------
## what's you job??
* Was machen Sie beruflich?
* was machst du beruflich?
- was sind Sie von Beruf?
- was bist du von Beruf?
	* Ich bin ....
	* Ich arbeite als ..... ايخ اابايتيي الس
	Ich arbeite als ...  --> i work as .....   --> The Answer 
	Beruf --> وظيفه 

 ----

للسؤال عن الحاله الاجتماعيه
* Wie ist Ihr Familienstand?
* Wie ist dein Familienstand?
	- Ich bin ...... 
Single / Ledig --> سنجل
Verlobt  --> خاطب او مخطوبه 
Verheiratet --> متزوج 
geschieden --> مطلق او مطلقه 
Verwitwet --> ارمل 

----
## which language do you speak?
- Welche Sprachen sprechen Sie?
- Welche sprachen spricht du?
	- Ich spreche Schr (very) gut Englisch
	- Ich spreche gut Englisch
	- Ich spreche ein bisschen Russisch

---

kosten يكلف
was kostet die Tasche ? --> للمفرد
		   der Tisch
		   der Stuhl
* was kostet das?
Wie viel kostet das? 

Answer--> (Es) kostet .......

Was kosten die Taschen   --> للجمع 
r,stuhl,..e  

------
Billig --> cheap 
teuer --> expensive
günstig --> suitable 
zu --> too --> i can't buy it
sehr --> very --> I can buy it 



