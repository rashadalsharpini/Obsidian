Word | individual | Plural
---|---|----
الام | Die Mutter | Die Mütter
الاب | Der Vater | Die Väter
الوالدين | .......... | Die Eltern
الجد | Der Opa | Die Opas
الجدة | Die Oma | Die Omas
الجدين | .......... | Die Großeltern
الاخ | Der Bruder | Die Brüder
الاخت | Die Schwester | Die Schwestern
‫الاخوات‬ | .......... | Die Geschwister
Die (Ehe)männer
Die (Ehe)frauen
Die Söhne
Die Töchter
Die Onkel ‫بعض‬ ‫زي‬
Die Tanten
Die Cousinen
Die Cousins
Die Neffen
die Nichten
die Enkel ‫بعض‬ ‫زي‬
die Enkelinnen

---
Der (Ehe)Mann
Die (Ehe)Frau
Der Sohn
Die Tochter
Der Onkel
Die Tante
Die Cousine
Der Cousin
Der Neffe
Die Nichte
Der Enkel
Die Enkelin

---
‫الزوج‬
‫الزوجة‬
‫االبن‬
‫االبنه‬
‫الخال‬/‫العم‬
‫الخالة‬/‫العمة‬
‫ة‬/‫الخال‬ ‫ة‬/‫العم‬ ‫بنت‬
‫ة‬/‫الخال‬ ‫ة‬/‫العم‬ ‫ابن‬
‫ت‬/‫االخ‬ ‫ابن‬
‫ت‬/‫االخ‬ ‫بنت‬
‫الحفيد‬
‫الحفيدة‬ 